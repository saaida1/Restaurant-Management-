package com.BeldiFlavored.ReservationTables.dto;
import com.BeldiFlavored.ReservationTables.model.Tables;
import com.BeldiFlavored.ReservationTables.util.TimesLot;
import lombok.*;

@Builder
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class ReservationDto {


    private Long id;

    public TimesLot timesLot;

    private Tables table;

}
